﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace filecontrol
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//file read
        {
            OpenFileDialog ofd = new OpenFileDialog();
            if(ofd.ShowDialog() == DialogResult.OK )
            {
                richTextBox1.Text = File.ReadAllText(ofd.FileName);
            }
        }

        private void button2_Click(object sender, EventArgs e)//file save
        {
            string fileName;
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Title = "경로를 지정하세요";
            saveFileDialog.OverwritePrompt = true;
            saveFileDialog.Filter = "Txt File(*.txt)|*.txt";//|Bitmap File(*.bmp)|PNG file(*png)

            if(saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                fileName = saveFileDialog.FileName;
                StreamWriter filewrite = new StreamWriter(fileName);
                filewrite.WriteLine("+입력 내용+");
                filewrite.WriteLine(richTextBox1.Text);
                MessageBox.Show("저장되었습니다");
                filewrite.Close();
            }
        }
    }
}
